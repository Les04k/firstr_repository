<?php 
include 'db/db.php';
include 'temp/header.php';
include 'temp/nav_m.php';
$sql = "select * from users where role = 'менеджер'";
$result = $db->query($sql);
$user = $result->fetch_assoc();
?>
<div class="container">
    <div class="row">
        <?php echo '<h1>Добро пожаловать '.$user['fio'].' </h1>'; ?>
    </div>
</div>
<?php
include 'temp/footer.php';
?>