<?php
include 'db/db.php'; 
$sql = "UPDATE `orders` SET `status` = 'закрыт' WHERE `id_order` = ".$_GET['id_order']."";
var_dump($sql);
$result = $db->query($sql);
header("location: see_order.php");
?>