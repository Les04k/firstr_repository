<?php
include 'db/db.php';
include 'temp/header.php';
include 'temp/nav_m.php';
?>
<br>
<div class="container">
    <div class="row">
        <table class="table ">
  <thead class="table-secondary">
    <tr>
      <th scope="col">№ заказа</th>
      <th scope="col">ФИО</th>
      <th scope="col">Тур</th>
      <th scope="col">Тип</th>
      <th scope="col">Услуга</th>
      <th scope="col">Дата прибытия</th>
      <th scope="col">Дата отъезда</th>
      <th scope="col">Статус</th>
      <th scope="col"></th>
    </tr>
  </thead>
  <tbody class="table-light">
    <?php 
    $sql = "SELECT orders.id_order, users.fio, turs.name_tur, type_group.name_type, uslugi.name_uslg, orders.date_1, orders.date_2, orders.status FROM orders, turs, users, type_group, uslugi WHERE orders.id_user = users.id_user and orders.id_tur = turs.id_tur and orders.type_group = type_group.id_type and orders.id_uslug = uslugi.id_uslug";
    $result = $db->query($sql);
    foreach($result as $row){
      
        echo '
            <tr>
      <th scope="row">'.$row['id_order'].'</th>
      <td>'.$row['fio'].'</td>
      <td>'.$row['name_tur'].'</td>
      <td>'.$row['name_type'].'</td>
      <td>'.$row['name_uslg'].'</td>
      <td>'.$row['date_1'].'</td>
      <td>'.$row['date_2'].'</td>
      <td>'.$row['status'].'</td>
      <td><div class="btn-group">
  '; if($row['status'] == 'закрыт'){
        echo '<a href="status1.php?id_order='.$row['id_order'].'" class="btn btn-success disabled"  aria-disabled="true">Подтвердить</a>';
      }
      elseif($row['status'] == 'подтвержден'){
        echo '<a href="status1.php?id_order='.$row['id_order'].'" class="btn btn-success disabled"  aria-disabled="true">Подтвердить</a>';
      }
      else{
        echo '<a href="status1.php?id_order='.$row['id_order'].'" class="btn btn-success" aria-current="page">Подтвердить</a>';
      }
      if($row['status'] == 'новый'){
         echo'
  <a href="status2.php?id_order='.$row['id_order'].'" class="btn btn-danger disabled"  aria-disabled="true">Закрыть</a>';
      }
      elseif($row['status'] == 'закрыт'){
        echo '<a href="status2.php?id_order='.$row['id_order'].'" class="btn btn-danger disabled"  aria-disabled="true">Закрыть</a>';
      }
      else{
       echo '<a href="status2.php?id_order='.$row['id_order'].'" class="btn btn-danger">Закрыть</a>';
      }
      if($row['status'] == 'закрыт'){
         echo '<a href="del_order.php?id_order='.$row['id_order'].'" class="btn btn-danger">Удалить</a>';
      }
     echo '
        </div></td>
    </tr>
     ';
    }
    ?>

  </tbody>
</table>
    </div>
</div>
<?php 
include 'temp/footer.php';
?>