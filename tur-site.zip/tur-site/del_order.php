<?php
include 'db/db.php'; 
$sql = "DELETE FROM `orders` WHERE id_order =".$_GET['id_order']."";
$db->query($sql);
header("location: see_order.php");
?>