<?php
include 'db/db.php'; 
$orders = "SELECT * FROM orders WHERE id_order = ".$_GET['id_order']."";
$result = $db->query($orders);
$order = $result->fetch_assoc();
if($order['status'] == 'закрыт'){
    header("location: see_order.php");

}
else{
$sql = "UPDATE `orders` SET `status` = 'подтвержден' WHERE `id_order` = ".$_GET['id_order']."";
$result = $db->query($sql);
header("location: see_order.php");
}


?>