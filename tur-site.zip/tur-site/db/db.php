<?php 
$db = new mysqli("localhost","root","","tur_site");
?>