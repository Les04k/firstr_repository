<?php
include 'db/db.php';
include 'temp/header.php';
include 'temp/nav_m.php';
$name_tur = $_POST['name_tur'];
$short_descript = $_POST['short_descript'];
$descript_tur = $_POST['descript_tur'];
$price_tur = $_POST['price_tur'];
$sql = "INSERT INTO `turs` (`name_tur`, `short_descript`, `descript_tur`, `price_tur`) VALUES ('$name_tur', '$short_descript', '$descript_tur', $price_tur)";
$db->query($sql);
?>
<br>
<div class="container">
    <div class="row">
    <h1 class="text-center">Добавление нового тура</h1>
        <form method="post">
<div class="row">
     <div class="col-4">
     <div class="mb-3">
    <label for="name_tur" class="form-label">Город</label>
    <input type="text" class="form-control" id="name_tur" name="name_tur">
  </div>
  </div>
     <div class="col-4">
          <div class="mb-3">
    <label for="price_tur" class="form-label">Цена тура</label>
    <input type="text" class="form-control" id="price_tur" name="price_tur">
  </div>
  </div>
  <div class="col-4">
      <div class="mb-3">
    <label for="short_descript" class="form-label">Название тура</label>
    <input type="text" class="form-control" id="short_descript" name="short_descript">
  </div>
  </div>
</div>
 
    <div class="mb-3">
    <label for="descript_tur" class="form-label">Описание тура</label>
    <input type="text" class="form-control" id="descript_tur" name="descript_tur">
  </div>
<div class="text-center">
    <button type="submit" class="btn btn-success">Добавить</button>
</div>
</form>
    </div>
</div>
<?php 
include 'temp/footer.php';
?>