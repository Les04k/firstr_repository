<?php
include 'db/db.php'; 
$sql = "DELETE FROM `turs` WHERE id_tur =".$_GET['id_tur']."";
$db->query($sql);
header("location: del_tur.php");
?>