<?php
include 'db/db.php';
include 'temp/header.php';
include 'temp/nav_m.php';
$name_tur = $_POST['name_tur'];
$short_descript = $_POST['short_descript'];
$descript_tur = $_POST['descript_tur'];
$price_tur = $_POST['price_tur'];
$sql = "INSERT INTO `turs` (`name_tur`, `short_descript`, `descript_tur`, `price_tur`) VALUES ('$name_tur', '$short_descript', '$descript_tur', $price_tur)";
$db->query($sql);
?>
<br>
<div class="container">
    <div class="row">
    <h1 class="text-center">Удаление тура</h1>

<div class="container">
    <div class="row">
        <table class="table ">
  <thead class="table-secondary">
    <tr>
      <th scope="col">№ тура</th>
      <th scope="col">Город проведения</th>
      <th scope="col">Название тура</th>
      <th scope="col">Описание</th>
      <th scope="col">Цена</th>
      <th scope="col"></th>
    </tr>
  </thead>
  <tbody class="table-light">
    <?php 
    $sql = "SELECT * FROM turs";
    $result = $db->query($sql);
    foreach($result as $row){
      $del = '<div class="btn-group">
  <a href="del_turs.php?id_tur='.$row['id_tur'].'" class="btn btn-danger">Удалить</a>
</div>';
        echo '
            <tr>
      <th scope="row">'.$row['id_tur'].'</th>
      <td>'.$row['name_tur'].'</td>
      <td>'.$row['short_descript'].'</td>
      <td>'.$row['descript_tur'].'</td>
      <td>'.$row['price_tur'].'</td>
        <td>'.$del.'</td>

    </tr>
     ';
    }
    ?>

  </tbody>
</table>
    </div>
</div>