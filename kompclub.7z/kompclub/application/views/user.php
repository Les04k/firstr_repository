<section id="popular">
    <br>
    <div class="container">
        <div class="row">
            <h1 class="text-light">Для каждого найдется своё место!</h1>
            <div class="card colors-cards text-light mb-3" style="max-width: 1240px;">
                <div class="row g-">
                    <div class="col-md-5">
                        <img src="images/arena.jpg" class="img-fluid rounded-around" alt="...">
                    </div>
                    <div class="col-md-7">
                        <div class="card-body">
                            <h5 class="card-title">У нас лучшие залы и компьютеры</h5>
                            <p class="card-text">Катка будет ИЗИ! Мы вас уверяем.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="card colors-cards text-light mb-3" style="max-width: 1240px;">
                <div class="row g-">
                    <div class="col-md-7">
                        <div class="card-body">
                            <h5 class="card-title">Самые тихие</h5>
                            <p class="card-text">Если вы любители стелса, ну или же вам нравиться играть в тишине, Solo-Room с личным мини-баром специально для вас!</p>
                        </div>
                    </div>
                    <div class="col-md-5">
                        <img src="images/solo_room.jpg" class="img-fluid rounded-around" alt="...">
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="card colors-cards text-light mb-3" style="max-width: 1240px;">
                <div class="row g-">
                    <div class="col-md-5">
                        <img src="images/bar.jpg" class="img-fluid rounded-around" alt="...">
                    </div>
                    <div class="col-md-7">
                        <div class="card-body">
                            <h5 class="card-title">Бар для всех</h5>
                            <p class="card-text">Если катка была потной, то наш бар поможет вам остыть, даже перекусить</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section id="tarif">
    <div class="container">
        <div class="row">
            <h1 class="text-light">Выбери подходящий тариф!</h1>
            <h3 class="text-light">Можешь забранировать заранее, что бы не ждать.</h3>
        </div>
        <div class="row">
            <div class="row row-cols-1 row-cols-md-2 g-4">
                <div class="col">
                    <div class="card colors-cards text-light">
                        <div class="card-body">
                            <h5 class="card-title">Тариф - "На одну катку"</h5>
                            <p class="card-text">1 час за 100 &#8381;</p>
                            <a href="zakaz.php" class="btn btn-primary">Заказать</a>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card colors-cards text-light">
                        <div class="card-body">
                            <h5 class="card-title">Тариф - "Ну еще два часика!"</h5>
                            <p class="card-text">2 часа за 170 &#8381;</p>
                            <a href="zakaz.php" class="btn btn-primary">Заказать</a>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card colors-cards text-light">
                        <div class="card-body">
                            <h5 class="card-title">Тариф - "Я теперь часть корабля"</h5>
                            <p class="card-text">за сутки 700 &#8381;</p>
                            <a href="zakaz.php" class="btn btn-primary">Заказать</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section id="onas">
    <div class="container">
        <div class="row">
            <h1>
                Мы только хорошего мнения о себе &#128541;
            </h1>
        </div>
        <div class="text">
            <div class="row">
                <p class="lh-base">Компьютерный клуб ФЕНИКС. У нас только лучшие девайсы, современные комплектующие. Только с нами вы можете почувствовать вкус игры в самых высоких настройках графики. Сыграть в то, что никогда не могли сыграть раньше. Взглянуть на игровой мир по новому в окружении друзей и знакомых. Мы находимся в г.Новочеркасск пр.Платовский 116. Ждем тебя на нашей арене "Феникс"</p>
            </div>

        </div>
        <br>
    </div>
</section>
<br><br>