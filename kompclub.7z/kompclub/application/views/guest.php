<section id="popular">
    <br>
    <div class="container">
        <div class="row">
            <?php 
            foreach($tarif as $row){
                echo
            
              '  <h1 class="text-black"></h1>
                <div class="card colors-cards text-light mb-3" style="max-width: 1240px;">
                    <div class="row g-">
                        <div class="col-md-5">
                        '.$row['image_tarif'].'
                        </div>
                        <div class="col-md-7">
                            <div class="card-body">
                                <h5 class="card-title">'.$row['name_tarif'] .'<br> За '.$row['time_play'].' час</h5>
                                <p class="card-text">'.$row['price_tarif'].' &#8381;</p>
                                <a href="registr.php" class="btn btn-primary">Заказать</a>
                            </div>
                        </div>
                    </div>
                </div>
           ';

            }
            ?>
            </div>
        </div>
</section>
<section id="onas">
    <div class="container">
        <div class="row">
            <h1>
                Мы только лучшего мнения о себе &#128541;
            </h1>
        </div>
        <div class="text">
            <div class="row">
                <p class="lh-base">Компьютерный клуб ФЕНИКС. У нас только лучшие девайсы, современные комплектующие. Только с нами вы можете почувствовать вкус игры в самых высоких настройках графики. Сыграть в то, что никогда не могли сыграть раньше. Взглянуть на игровой мир по новому в окружении друзей и знакомых. Мы находимся в г.Новочеркасск пр.Платовский 116. Ждем тебя на нашей арене "Феникс"</p>
            </div>

        </div>
        <br>
    </div>
</section>
<br><br>