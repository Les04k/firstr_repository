<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card shadow">
                <div class="card-header bg-primary text-white">
                    <h2 class="text-center">Регистрация</h2>
                </div>
                <div class="card-body">
                    <?php if ($this->session->flashdata('error')): ?>
                        <div class="alert alert-danger"><?= $this->session->flashdata('error') ?></div>
                    <?php endif; ?>
                    
                    <?php if ($this->session->flashdata('success')): ?>
                        <div class="alert alert-success"><?= $this->session->flashdata('success') ?></div>
                    <?php endif; ?>
                    
                    <?php echo validation_errors('<div class="alert alert-danger">', '</div>'); ?>
                    
                    <form method="post">
                        <div class="mb-3">
                            <label for="fio" class="form-label">ФИО</label>
                            <input type="text" name="fio" id="fio" class="form-control" value="<?= set_value('fio') ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" name="email" id="email" class="form-control" value="<?= set_value('email') ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="login" class="form-label">Логин</label>
                            <input type="text" name="login" id="login" class="form-control" value="<?= set_value('login') ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Пароль</label>
                            <input type="password" name="password" id="password" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="passconf" class="form-label">Подтверждение пароля</label>
                            <input type="password" name="passconf" id="passconf" class="form-control" required>
                        </div>
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary">Зарегистрироваться</button>
                        </div>
                    </form>
                    <div class="mt-3 text-center">
                        Уже есть аккаунт? <a href="<?= base_url('main/auth') ?>">Войти</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>