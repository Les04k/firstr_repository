</head>

<body>
  <div class="sticky-top container">
    <div class="row">
      <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
          <a class="navbar-brand" href="<?= base_url() ?>">Феникс</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>

          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
              <li class="nav-item">
                <a class="nav-link" href="#popular">Тарифы</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#onas">О Нас</a>
              </li>
              <?php if (isset($user) && $user['role'] == 'admin'): ?>
                <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    Админ-панель
                  </a>
                  <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <li><a class="dropdown-item" href="<?= base_url('admin/orders') ?>">Заказы</a></li>
                    <li><a class="dropdown-item" href="<?= base_url('admin/adduslug') ?>">Добавить тариф</a></li>
                    <li><a class="dropdown-item" href="<?= base_url('main/usercontrol') ?>">Пользователи</a></li>
                  </ul>
                </li>
              <?php endif; ?>
            </ul>

            <ul class="navbar-nav">
              <?php if (isset($user)): ?>
                <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    <?= $user['fio'] ?>
                  </a>
                  <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                    <li><a class="dropdown-item" href="<?= base_url('bookingcontroller/cabinet') ?>">Личный кабинет</a></li>
                    <li>
                      <hr class="dropdown-divider">
                    </li>
                    <li><a class="dropdown-item" href="<?= base_url('main/logout') ?>">Выйти</a></li>
                  </ul>
                </li>
              <?php else: ?>
                <li class="nav-item">
                  <a class="nav-link active text-light" aria-current="page" href="<?= base_url('main/auth') ?>">Войти</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link text-light" href="<?= base_url('main/registr') ?>">Регистрация</a>
                </li>
              <?php endif; ?>
            </ul>
          </div>
        </div>
      </nav>
    </div>
  </div>