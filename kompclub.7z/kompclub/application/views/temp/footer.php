<footer class="fixed-bottom">
<nav class="navbars navbar-expand-lg">
  <div class="container-fluid">
    <a class="navbar-brand text-light" href="index.php">Все права защищены &copy; <br>Песоцкий А.С.</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="col-lg-9"></div>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
    </div>
  </div>
</nav>
</footer>
</body>
</html>