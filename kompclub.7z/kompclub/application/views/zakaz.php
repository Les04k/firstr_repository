<?php
session_start();


include 'temp/dbconnect.php';
include 'temp/header.php';
?>

<?php include 'temp/footer.php'?>