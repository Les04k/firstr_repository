<?php
include 'temp/header.php';

    include 'temp/navbar.php';
    include 'guest.php';


?>


<?php
include 'temp/footer.php';
?>