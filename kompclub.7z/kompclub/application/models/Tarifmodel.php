<?php
class Tarifmodel extends CI_Model{
    public function tarifselect(){
        $sql = "SELECT * FROM tarif";
        $result = $this->db->query($sql);
        return $result->result_array();
    }

}