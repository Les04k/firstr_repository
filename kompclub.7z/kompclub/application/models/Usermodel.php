<?php 
class Usermodel extends CI_Model {

    public function registr($fio, $email, $login, $password) {
        // Хешируем пароль перед сохранением
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        
        $data = [
            'fio' => $fio,
            'email' => $email,
            'login' => $login,
            'password' => $hashed_password,
            'role' => 'user',
            'avatar' => 'default.jpg'
        ];
        
        return $this->db->insert('users', $data);
    }

    public function auth($login, $password) {
        $this->db->where('login', $login);
        $query = $this->db->get('users');
        
        if ($query->num_rows() == 1) {
            $user = $query->row_array();
            // Проверяем пароль с хешем
            if (password_verify($password, $user['password'])) {
                return $user;
            }
        }
        return false;
    }

    public function get_user_by_id($id) {
        $this->db->where('id_user', $id);
        $query = $this->db->get('users');
        return $query->row_array();
    }

    public function get_all_users() {
        $query = $this->db->get('users');
        return $query->result_array();
    }
}