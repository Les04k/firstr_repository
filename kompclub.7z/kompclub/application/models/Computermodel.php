<?php
class Computermodel extends CI_Model{
    public function tovarselect(){
        $sql = "SELECT * FROM computers";
        $result = $this->db->query($sql);
        return $result->result_array();
    }

}