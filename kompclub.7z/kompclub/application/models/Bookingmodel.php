<?php 
class Bookingmodel extends CI_Model{
    
}