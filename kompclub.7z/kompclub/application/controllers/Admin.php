<?php
class Admin extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('usermodel');
        $this->load->model('tarifmodel');
        $this->load->model('bookingmodel');
        $this->load->helper('url');
        $this->load->library('session');
        
        // Проверяем авторизацию и права администратора
        if (!$this->session->userdata('user') || $this->session->userdata('user')['role'] != 'admin') {
            redirect('main/index');
        }
    }
    
    public function orders() {
        $data['orders'] = $this->bookingmodel->get_all_orders();
        
        $this->load->view('temp/header');
        $this->load->view('temp/navbar');
        $this->load->view('admin/orders', $data);
        $this->load->view('temp/footer');
    }

    public function adduslug() {
        if ($this->input->post()) {
            $this->load->library('form_validation');
            
            $this->form_validation->set_rules('name_tarif', 'Название тарифа', 'required');
            $this->form_validation->set_rules('time_play', 'Время игры', 'required|numeric');
            $this->form_validation->set_rules('price_tarif', 'Цена', 'required|numeric');
            
            if ($this->form_validation->run()) {
                $data = [
                    'name_tarif' => $this->input->post('name_tarif'),
                    'time_play' => $this->input->post('time_play'),
                    'price_tarif' => $this->input->post('price_tarif'),
                    'image_tarif' => $this->input->post('image_tarif') ?? '<img class="img-fluid rounded-start" src="images/default.jpg">'
                ];
                
                if ($this->tarifmodel->add_tarif($data)) {
                    $this->session->set_flashdata('success', 'Тариф успешно добавлен');
                    redirect('admin/adduslug');
                } else {
                    $this->session->set_flashdata('error', 'Ошибка при добавлении тарифа');
                }
            }
        }
        
        $this->load->view('temp/header');
        $this->load->view('temp/navbar');
        $this->load->view('admin/add_tarif');
        $this->load->view('temp/footer');
    }
    
    public function status($order_id, $status) {
        if ($this->bookingmodel->update_order_status($order_id, $status)) {
            $this->session->set_flashdata('success', 'Статус заказа обновлен');
        } else {
            $this->session->set_flashdata('error', 'Ошибка при обновлении статуса');
        }
        redirect('admin/orders');
    }
}