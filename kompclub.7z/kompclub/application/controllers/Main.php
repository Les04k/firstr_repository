<?php
class Main extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('tarifmodel');
        $this->load->model('usermodel');
        $this->load->helper('url');
        $this->load->library('session');
    }
    
    public function index() {
        $data = [];
        
        // Проверяем авторизацию пользователя
        if ($this->session->userdata('user')) {
            $data['user'] = $this->session->userdata('user');
        }
        
        $data['tarif'] = $this->tarifmodel->tarifselect();
        
        $this->load->view('temp/header');
        $this->load->view('temp/navbar', $data);
        $this->load->view('guest', $data);
        $this->load->view('temp/footer');
    }

    public function auth() {
        // Если пользователь уже авторизован, перенаправляем на главную
        if ($this->session->userdata('user')) {
            redirect('main/index');
        }
        
        if ($this->input->post()) {
            $this->load->library('form_validation');
            
            $this->form_validation->set_rules('login', 'Логин', 'required');
            $this->form_validation->set_rules('password', 'Пароль', 'required');
            
            if ($this->form_validation->run()) {
                $login = $this->input->post('login');
                $password = $this->input->post('password');
                
                $user = $this->usermodel->auth($login, $password);
                
                if ($user) {
                    $this->session->set_userdata('user', $user);
                    redirect('main/index');
                } else {
                    $this->session->set_flashdata('error', 'Неверный логин или пароль');
                }
            }
        }
        
        $this->load->view('temp/header');
        $this->load->view('temp/navbar');
        $this->load->view('login_form');
        $this->load->view('temp/footer');
    }

    public function registr() {
        if ($this->input->post()) {
            $this->load->library('form_validation');
            
            $this->form_validation->set_rules('fio', 'ФИО', 'required|min_length[5]');
            $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
            $this->form_validation->set_rules('login', 'Логин', 'required|min_length[3]|is_unique[users.login]');
            $this->form_validation->set_rules('password', 'Пароль', 'required|min_length[6]');
            $this->form_validation->set_rules('passconf', 'Подтверждение пароля', 'required|matches[password]');
            
            if ($this->form_validation->run()) {
                $fio = $this->input->post('fio');
                $email = $this->input->post('email');
                $login = $this->input->post('login');
                $password = $this->input->post('password');
                
                if ($this->usermodel->registr($fio, $email, $login, $password)) {
                    $this->session->set_flashdata('success', 'Регистрация успешна! Теперь вы можете войти.');
                    redirect('main/auth');
                } else {
                    $this->session->set_flashdata('error', 'Ошибка регистрации. Попробуйте позже.');
                }
            }
        }
        
        $this->load->view('temp/header');
        $this->load->view('temp/navbar');
        $this->load->view('registration_form');
        $this->load->view('temp/footer');
    }

    public function logout() {
        $this->session->unset_userdata('user');
        redirect('main/index');
    }

    public function usercontrol() {
        // Проверяем, является ли пользователь администратором
        if (!$this->session->userdata('user') || $this->session->userdata('user')['role'] != 'admin') {
            redirect('main/index');
        }
        
        $data['users'] = $this->usermodel->get_all_users();
        
        $this->load->view('temp/header');
        $this->load->view('temp/navbar');
        $this->load->view('admin/users', $data);
        $this->load->view('temp/footer');
    }
}