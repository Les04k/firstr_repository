<?php 
class Bookingmodel extends CI_Model {
    
    public function get_all_orders() {
        $this->db->select('orders.*, users.fio, tarif.name_tarif');
        $this->db->from('orders');
        $this->db->join('users', 'users.id_user = orders.id_user');
        $this->db->join('tarif', 'tarif.id_tarif = orders.id_tarif');
        $query = $this->db->get();
        return $query->result_array();
    }
    
    public function create_order($user_id, $tarif_id, $date) {
        $data = [
            'id_user' => $user_id,
            'id_tarif' => $tarif_id,
            'date' => $date,
            'status' => 'pending'
        ];
        return $this->db->insert('orders', $data);
    }
    
    public function update_order_status($order_id, $status) {
        $this->db->where('id_order', $order_id);
        return $this->db->update('orders', ['status' => $status]);
    }
    
    public function get_user_orders($user_id) {
        $this->db->where('id_user', $user_id);
        $this->db->join('tarif', 'tarif.id_tarif = orders.id_tarif');
        $query = $this->db->get('orders');
        return $query->result_array();
    }
}